Especificaciones del Proyecto

Aplicaci�n web ASP.NET MVC 5
HTML5
CSS3
Bootstrap
Knockout.js
Jquery
Ajax
C#

Distribuida en capas de presentaci�n, negocio y transversal.

La aplicaci�n fue desarrollada en visual studio .net 2015 y se ejecuta de forma correcta, cumpliendo con el objetivo de validar los archivos Xpdl.
